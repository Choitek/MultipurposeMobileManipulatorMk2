#include <Arduino.h>
#include <Servo.h>

// --- MOTOR CONTROLLER --- //
class MotorController {
  public:
    MotorController(int dir1, int pwm1, int dir2, int pwm2);
    void setVelocities(int velocity1, int velocity2);
    void update(float delay = 0.5);
    void initialize();
  private:
    int DIR1;
    int PWM1;
    int DIR2;
    int PWM2;
    int v1;
    int toV1;
    int v2;
    int toV2;
    unsigned long endTime;
};

// --- STEPPER MOTOR --- //
class StepperMotor {
  public:
    StepperMotor(int stepPin, int dirPin, int limitPin, int max, bool invertDir = false);
    void stepTo(int steps, bool ignoreHome = false);
    void step(int steps, bool ignoreHome = false);
    void initialize();
    void home();
    int getPos();  
    void update(float delay = 0.01);
  private:
    int STEP;
    int DIR;
    int LIMIT; 
    unsigned long endTime;    
    bool stepHigh;
    void zero();
    bool invert;
    bool homed;    
    int maxPos;
    int toPos;
    int pos;    
};

// --- SERVO MOTOR ---//
class ServoMotor {
  public:
    ServoMotor(int pin, bool invertDir = false);
    void rotateTo(int angle, bool OnOff = false);
    void rotate(int angle);
    void on(); void off(); 
    bool isAttached();
    void update(float delay = 5.0);
    int getPos();
  private:
    Servo SERVO;
    int PIN;    
    unsigned long endTime;
    float delayTime;   
    bool attached;
    bool invert;
    int toPos;
    int pos;
};

// --- RANGE FINDER --- //
class RangeFinder {
  public:
    RangeFinder(int echoPin, int trigPin, int min = 0, int max = 150, 
                int delay = 100, int timeOut = 5000000);  
    void initialize();
    void update();
    int getRange();
  private:
    int ECHO;  
    int TRIG;
    long timeOutMicros;   
    unsigned long endTime;
    float delayTime;      
    int minRange;
    int maxRange;
    int range;
};

// --- FANS --- //
class Fans {
  public:
    Fans(int pin);
    void initialize();
    void on(); void off();
  private:
    int PIN;    
};

// --- VOLTMETER --- //
class Voltmeter {
  public:
    Voltmeter(int pin);
    void initialize();
    int voltage();
  private:
    int PIN;
};


