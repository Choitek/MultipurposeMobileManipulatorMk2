#include "MK2.h"

// --- MOTOR CONTROLLER --- //
MotorController::MotorController(int dir1, int pwm1, int dir2, int pwm2) {
  //assign pins
  DIR1 = dir1; 
  PWM1 = pwm1;
  DIR2 = dir2;
  PWM2 = pwm2;
  //set initial velocities
  v1 = 0; toV1 = 0;
  v2 = 0; toV2 = 0;
  //set update time
  endTime = 0;
}
void MotorController::initialize() {
  pinMode(DIR1,OUTPUT);
  pinMode(PWM1,OUTPUT);
  pinMode(DIR2,OUTPUT);
  pinMode(PWM2,OUTPUT);
}
void MotorController::setVelocities(int velocity1, int velocity2) { 
  //set velocities
  toV1 = velocity1;
  toV2 = velocity2;  
  //clamp velocities
  if(toV1 > 255)  { toV1 = 255;  }
  if(toV1 < -255) { toV1 = -255; }
  if(toV2 > 255)  { toV2 = 255;  }
  if(toV2 < -255) { toV2 = -255; }
}
void MotorController::update(float delay) {
  unsigned long t = millis();
  if(t > endTime) {
    //increment the time
    endTime = t + delay;
    //accelerate velocity 1
    if(v1 < toV1) { v1 += 1; } 
    if(v1 > toV1) { v1 -= 1; }
    //accelerate velocity 2
    if(v2 < toV2) { v2 += 1; } 
    if(v2 > toV2) { v2 -= 1; }
    //control motor 1 
    if(v1 > 0) { digitalWrite(DIR1,HIGH); } 
    else { digitalWrite(DIR1,LOW); }
    analogWrite(PWM1,abs(v1));      
    //control motor 2 
    if(v2 > 0) { digitalWrite(DIR2,HIGH); } 
    else { digitalWrite(DIR2,LOW); }
    analogWrite(PWM2,abs(v2));
  }
}

// --- STEPPER MOTOR --- //
StepperMotor::StepperMotor(int stepPin, int dirPin, int limitPin, 
                           int max, bool invertDir) {
  //assign pins
  STEP = stepPin;
  DIR = dirPin;
  LIMIT = limitPin;
  //set maximum position
  maxPos = max;
  //set inversion
  invert = invertDir;
  //homed
  homed = true;
  endTime = 0;
  toPos = 0;
  pos = 0;
}
void StepperMotor::initialize() {
  pinMode(STEP,OUTPUT);
  pinMode(DIR,OUTPUT);
  pinMode(LIMIT,INPUT);
}
void StepperMotor::stepTo(int steps, bool ignoreHome) {
  //check calibration
  if(homed || ignoreHome) {
    //set goal position and clamp
    toPos = steps;
    //if(toPos < 0) { toPos = 0; } 
    if(toPos > maxPos) { toPos = maxPos; }
  }
}
void StepperMotor::step(int steps, bool ignoreHome) {
  //check calibration
  if(homed || ignoreHome) {
    //set goal position and clamp
    toPos += steps;
  }
}
void StepperMotor::home() {
  homed = false;
  toPos = -20000;
  pos = 0;
}
void StepperMotor::zero() {
  digitalWrite(STEP,LOW);
  stepHigh = false;
  endTime = 0;
  toPos = 0;
  pos = 0;  
}
void StepperMotor::update(float delay) {
  if(pos != toPos) {
    unsigned long t = millis();
    if(t > endTime) {
      //increment the time
      endTime = t + delay;
      //turn HIGH or LOW to step next
      if(stepHigh) {
        digitalWrite(STEP,LOW);
        stepHigh = false;
      } else {
        digitalWrite(STEP,HIGH);
        stepHigh = true;
        //go forward
        if(pos < toPos) { 
          if(invert) { digitalWrite(DIR,HIGH); } 
          else { digitalWrite(DIR,LOW); }
          pos += 1; 
        } 
        //go backward
        if(pos > toPos) { 
          if(invert) { digitalWrite(DIR,LOW); } 
          else { digitalWrite(DIR,HIGH); }
          pos -= 1; 
          //check limit switch
          if(digitalRead(LIMIT) == HIGH) { zero(); homed = true; }    
        }
      }
    } 
  }
}
int StepperMotor::getPos() { return pos; }

// --- SERVO MOTOR --- //
ServoMotor::ServoMotor(int pin, bool invertDir) {
  PIN = pin;
  invert = invertDir;
  attached = false;
}
void ServoMotor::on() {
  SERVO.attach(PIN);
  attached = true;
  endTime = 0;
  pos = 90; 
}
void ServoMotor::off() {
  SERVO.detach();
  attached = false;
}
void ServoMotor::rotateTo(int angle, bool OnOff) {
  //if On/Off enabled, turn servo off if negative value
  if(OnOff) {
    if (angle < 0) { off(); }
    else if (!attached) { on(); }
  }
  //move only if attached
  if(attached) {
    //set goal position and clamp
    toPos = angle;
    if(toPos < 0)   { toPos = 0;   } 
    if(toPos > 180) { toPos = 180; }
  }
}
void ServoMotor::rotate(int angle) {
  //move only if attached
  if(attached) {
    //set goal position and clamp
    toPos += angle;
    if(toPos < 0)   { toPos = 0;   } 
    if(toPos > 180) { toPos = 180; }
  }
}
void ServoMotor::update(float delay) {
  //move only if attached
  if(attached) {
    unsigned long t = millis();
    if(t > endTime) {
      //increment the time
      endTime = t + delay;
      //get closer to goal position
      if(pos < toPos) { pos += 1; } 
      if(pos > toPos) { pos -= 1; }
      //write the servo position
      if(invert) { SERVO.write(180-pos); }
      else { SERVO.write(pos); }
    } 
  }
}
int ServoMotor::getPos() { return pos; }
bool ServoMotor::isAttached() { return attached; }

// --- RANGE FINDER --- //
RangeFinder::RangeFinder(int echoPin, int trigPin, int min, int max, 
                         int delay, int timeOut) {
  ECHO = echoPin;
  TRIG = trigPin;
  minRange = min;
  maxRange = max;
  delayTime = delay;
  timeOutMicros = timeOut;
}
void RangeFinder::initialize() {
  pinMode(TRIG,OUTPUT);
  pinMode(ECHO,INPUT);
  range = -1;
  endTime = 0;
}
void RangeFinder::update() {
  unsigned long t = millis();
  if(t > endTime) {
    //increment the time
    endTime = t + delayTime;
    //pulse ultrasound out
    digitalWrite(TRIG, LOW); delayMicroseconds(2); 
    digitalWrite(TRIG, HIGH); delayMicroseconds(8); 
    digitalWrite(TRIG, LOW);
    //Measure distance
    long duration = pulseIn(ECHO, HIGH, timeOutMicros);
    long distance = duration/58.2;
    if(minRange < distance && distance < maxRange){
      range = int(distance);
    } else {
      range = -1;
    }
  } 
}
int RangeFinder::getRange() { return range; }

// --- FANS --- //
Fans::Fans(int pin) { PIN = pin; }
void Fans::initialize() { pinMode(PIN,OUTPUT); }
void Fans::on() { digitalWrite(PIN, HIGH); }
void Fans::off() { digitalWrite(PIN, LOW); }

// --- VOLTMETER --- //
Voltmeter::Voltmeter(int pin) { PIN = pin; }
void Voltmeter::initialize() { pinMode(PIN,INPUT); }
int Voltmeter::voltage() { 
  //convert 0-1023 analog in to 0-15 volts
  return int(analogRead(PIN)*2.15062-22.98);
}





